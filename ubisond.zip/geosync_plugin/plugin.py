# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgsMapToolEmitPoint
from qgis.core import (
    QgsPointXY, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsProject
)


class UbisondPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.map_tool = None

    def initGui(self):
        self.action = QAction("📍 Ubisond", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setToolTip("Ubisond: hacé click en el mapa para registrar un punto")
        self.action.triggered.connect(self.toggle_tool)

        self.iface.addPluginToMenu("Ubisond", self.action)
        self.iface.addToolBarIcon(self.action)

        self.map_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.map_tool.canvasClicked.connect(self.on_canvas_clicked)
        self.map_tool.setAction(self.action)

    def unload(self):
        self.iface.removePluginMenu("Ubisond", self.action)
        self.iface.removeToolBarIcon(self.action)

    def toggle_tool(self, checked):
        if checked:
            self.iface.mapCanvas().setMapTool(self.map_tool)
            self.iface.mainWindow().statusBar().showMessage(
                "Ubisond activo — hacé click en el mapa para registrar un punto"
            )
        else:
            self.iface.mapCanvas().unsetMapTool(self.map_tool)
            self.iface.mainWindow().statusBar().clearMessage()

    def on_canvas_clicked(self, point: QgsPointXY, button):
        if button != Qt.LeftButton:
            return

        # Convertir a WGS84
        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(canvas_crs, wgs84, QgsProject.instance())
        point_wgs84 = transform.transform(point)

        lat = round(point_wgs84.y(), 7)
        lon = round(point_wgs84.x(), 7)

        from .dialog import UbisondDialog
        dlg = UbisondDialog(lat=lat, lon=lon, iface=self.iface)
        dlg.exec_()
