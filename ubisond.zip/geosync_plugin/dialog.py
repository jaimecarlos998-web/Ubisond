# -*- coding: utf-8 -*-
import datetime
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QTextEdit, QComboBox,
    QPushButton, QMessageBox, QFrame
)
from qgis.PyQt.QtCore import Qt
from .supabase import SupabaseClient

TOP_OPTIONS = [
    "OBSERVACIONES",
    "MAL DOCUMENTADO",
    "ATENUACION",
    "BOTELLA NO DOCUMENTADA",
    "BOTELLA ROBADA",
    "CORTE DE PELO",
    "CORTE FO",
    "MAL RECLAMADO",
    "REACONDICIONAMIENTO",
    "REASIGNACION",
    "CABLE DAÑADO",
]

BG       = "#1e2130"
PANEL    = "#252a3d"
ACCENT   = "#4a90d9"
TEXT     = "#e8eaf0"
MUTED    = "#8b91a8"
INPUT_BG = "#2e3450"
INPUT_BD = "#3d4466"

STYLE = f"""
QDialog {{
    background-color: {BG};
    color: {TEXT};
    font-family: 'Segoe UI', Arial, sans-serif;
}}
QLabel {{ color: {TEXT}; font-size: 12px; }}
QLabel#title {{ font-size: 16px; font-weight: bold; color: {ACCENT}; }}
QLabel#sub   {{ font-size: 11px; color: {MUTED}; }}
QLabel#lbl   {{ color: {MUTED}; font-size: 11px; font-weight: bold; letter-spacing: 1px; }}
QLabel#ro    {{
    background-color: {INPUT_BG}; color: {MUTED};
    border: 1px solid {INPUT_BD}; border-radius: 4px;
    padding: 6px 10px; font-size: 12px;
}}
QLineEdit, QTextEdit, QComboBox {{
    background-color: {INPUT_BG}; color: {TEXT};
    border: 1px solid {INPUT_BD}; border-radius: 4px;
    padding: 6px 10px; font-size: 12px;
}}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid {ACCENT}; }}
QComboBox::drop-down {{ border: none; padding-right: 8px; }}
QComboBox QAbstractItemView {{
    background-color: {PANEL}; color: {TEXT};
    border: 1px solid {INPUT_BD};
    selection-background-color: {ACCENT};
}}
QPushButton#save {{
    background-color: {ACCENT}; color: white;
    border: none; border-radius: 5px;
    padding: 10px 24px; font-size: 13px; font-weight: bold;
}}
QPushButton#save:hover   {{ background-color: #5aa0e8; }}
QPushButton#save:pressed {{ background-color: #3a80c9; }}
QPushButton#cancel {{
    background-color: transparent; color: {MUTED};
    border: 1px solid {INPUT_BD}; border-radius: 5px;
    padding: 10px 20px; font-size: 13px;
}}
QPushButton#cancel:hover {{ color: {TEXT}; border-color: {TEXT}; }}
QFrame#sep {{ background-color: {INPUT_BD}; max-height: 1px; }}
"""


class UbisondDialog(QDialog):

    def __init__(self, lat: float, lon: float, iface=None):
        super().__init__(iface.mainWindow() if iface else None)
        self.lat   = lat
        self.lon   = lon
        self.fecha = datetime.date.today().strftime("%d-%m-%Y")

        self.setWindowTitle("Ubisond — Registrar punto")
        self.setMinimumWidth(420)
        self.setStyleSheet(STYLE)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        layout.setContentsMargins(24, 24, 24, 24)

        # Encabezado
        title = QLabel("Registrar punto")
        title.setObjectName("title")
        sub = QLabel(f"📍 {self.lat:.6f}, {self.lon:.6f}")
        sub.setObjectName("sub")
        layout.addWidget(title)
        layout.addWidget(sub)
        layout.addWidget(self._sep())

        # Campos automáticos
        auto = QFormLayout()
        auto.setSpacing(8)
        auto.setLabelAlignment(Qt.AlignLeft)
        self._ro(auto, "ID",           "asignado automáticamente")
        self._ro(auto, "FECHA CIERRE", self.fecha)
        self._ro(auto, "LATITUD",      str(self.lat))
        self._ro(auto, "LONGITUD",     str(self.lon))
        layout.addLayout(auto)
        layout.addWidget(self._sep())

        # Campos editables
        form = QFormLayout()
        form.setSpacing(10)
        form.setLabelAlignment(Qt.AlignLeft)

        self.wo = QLineEdit()
        self.wo.setPlaceholderText("Número de Work Order")
        self._field(form, "WO (nombre)", self.wo)

        self.ci = QLineEdit()
        self.ci.setPlaceholderText("CI Afectado")
        self._field(form, "CI", self.ci)

        self.top = QComboBox()
        self.top.addItems(TOP_OPTIONS)
        self._field(form, "TOP", self.top)

        self.comentario = QTextEdit()
        self.comentario.setPlaceholderText("Comentarios adicionales...")
        self.comentario.setFixedHeight(80)
        self._field(form, "COMENTARIO", self.comentario)

        layout.addLayout(form)

        # Botones
        btns = QHBoxLayout()
        btns.setSpacing(10)

        btn_cancel = QPushButton("Cancelar")
        btn_cancel.setObjectName("cancel")
        btn_cancel.clicked.connect(self.reject)

        btn_save = QPushButton("Guardar →")
        btn_save.setObjectName("save")
        btn_save.clicked.connect(self.save)
        btn_save.setDefault(True)

        btns.addWidget(btn_cancel)
        btns.addStretch()
        btns.addWidget(btn_save)
        layout.addLayout(btns)

    def _sep(self):
        f = QFrame(); f.setObjectName("sep"); f.setFrameShape(QFrame.HLine); return f

    def _ro(self, form, label, value):
        lbl = QLabel(label); lbl.setObjectName("lbl")
        val = QLabel(value); val.setObjectName("ro")
        form.addRow(lbl, val)

    def _field(self, form, label, widget):
        lbl = QLabel(label); lbl.setObjectName("lbl")
        form.addRow(lbl, widget)

    def save(self):
        data = {
            "nombre":       self.wo.text().strip(),
            "ci":           self.ci.text().strip(),
            "top":          self.top.currentText(),
            "comentario":   self.comentario.toPlainText().strip(),
            "latitud":      self.lat,
            "longitud":     self.lon,
            "fecha cierre": self.fecha,
        }

        try:
            client = SupabaseClient()
            result = client.insert(data)
            assigned_id = result.get("id", "—")

            QMessageBox.information(
                self, "✅ Guardado",
                f"Punto registrado correctamente en la base de datos Mobisond.\nID: {assigned_id}"
            )
            self.accept()

        except Exception as e:
            QMessageBox.critical(
                self, "Error al guardar",
                f"No se pudo insertar en Supabase:\n\n{str(e)}"
            )
