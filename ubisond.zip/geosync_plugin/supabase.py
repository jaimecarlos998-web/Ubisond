# -*- coding: utf-8 -*-
import json
import urllib.request
import urllib.error

SUPABASE_URL = "https://gnqvhlpknxtdnzuxfybc.supabase.co/rest/v1"
SUPABASE_KEY = "sb_publishable_dUhjyCfRfNtLVLfOYnJ1WA_hfPD3kk9"
TABLE        = "casos_tl"


class SupabaseClient:

    def insert(self, data: dict) -> dict:
        url     = f"{SUPABASE_URL}/{TABLE}"
        payload = json.dumps(data).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Content-Type":  "application/json",
                "apikey":        SUPABASE_KEY,
                "Authorization": f"Bearer {SUPABASE_KEY}",
                "Prefer":        "return=representation",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=15) as response:
                result = json.loads(response.read().decode())
                return result[0] if isinstance(result, list) else result

        except urllib.error.HTTPError as e:
            body = e.read().decode()
            if e.code == 401:
                raise ConnectionError("Error de autenticación (401). Verificá la API key.")
            elif e.code == 403:
                raise ConnectionError("Sin permisos (403). Revisá las políticas RLS de casos_tl.")
            elif e.code == 404:
                raise ConnectionError("Tabla no encontrada (404). Verificá que 'casos_tl' exista.")
            else:
                raise ConnectionError(f"Error HTTP {e.code}:\n{body}")

        except urllib.error.URLError as e:
            raise ConnectionError(f"Sin conexión:\n{e.reason}")
