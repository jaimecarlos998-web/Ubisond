═══════════════════════════════════════════════════
  GeoSync Plugin para QGIS v0.2 — Supabase directo
═══════════════════════════════════════════════════

─── INSTALACIÓN ───────────────────────────────────

1. Copiá la carpeta "geosync_plugin" a la carpeta de plugins de QGIS:

   Windows:  C:\Users\TU_USUARIO\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\
   Mac/Linux: ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/

2. QGIS → Plugins → Administrar e instalar plugins
   → Pestaña "Instalados" → Activar "GeoSync"

No requiere configuración adicional. La conexión a Supabase ya está integrada.


─── USO ───────────────────────────────────────────

1. Clic en el botón "📍 GeoSync" en la barra de herramientas
2. Clic en cualquier punto del mapa
3. Completar WO, CI, TOP y Comentarios
4. Clic en "Guardar →"
   → El registro se inserta en Supabase (tabla: casos_tl)
   → El ID lo asigna Supabase automáticamente (sin conflictos entre usuarios)


─── ESTRUCTURA DE LA TABLA casos_tl ───────────────

  id          SERIAL (autoincrement) — asignado por Supabase
  fecha_hora  TEXT o TIMESTAMP
  wo          TEXT
  ci          TEXT
  top         TEXT
  comentarios TEXT
  latitud     FLOAT
  longitud    FLOAT


─── ARCHIVOS ──────────────────────────────────────

  __init__.py   → entrada del plugin
  plugin.py     → herramienta de click en el mapa
  dialog.py     → formulario de registro
  supabase.py   → cliente REST de Supabase
  metadata.txt  → info del plugin para QGIS
